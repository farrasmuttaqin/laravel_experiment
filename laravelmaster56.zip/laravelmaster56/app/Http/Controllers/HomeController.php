<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

class HomeController extends Controller
{
    
    public function showHome(){

    	$nama="farras";
    	$gelar = "s.Kom";

    	return view('welcome', compact('nama','gelar'));
    }

    public function showContact(){

    	$nama="farras";
    	$gelar = "s.Kom";

    	return view('hal_contact', compact('nama','gelar'));
    }

    public function showAbout(){

    	$nama="farras";
    	$gelar = "s.Kom";

    	return view('hal_about', compact('nama','gelar'));
    }


}
