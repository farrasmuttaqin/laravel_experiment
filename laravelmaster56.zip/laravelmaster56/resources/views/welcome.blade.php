@extends('layout.apps')
@section('title', 'Home')
@section('content')
<p> ini halaman home  {{ $nama }} {{ $gelar }} </p>
@endsection