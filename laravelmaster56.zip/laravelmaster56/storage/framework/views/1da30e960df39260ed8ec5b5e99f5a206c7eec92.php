<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>
<p> ini halaman home  <?php echo e($nama); ?> <?php echo e($gelar); ?> </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.apps', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>