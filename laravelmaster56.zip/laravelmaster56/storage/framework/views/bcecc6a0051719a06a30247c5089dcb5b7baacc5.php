<html lang="end" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title> Belajar laravel</title>
    </head>
    <body>
        <h1> belajar </h1>
        <hr>
            <a href="<?php echo e(url('/')); ?>"> Home </a> &bullet;
            
            <a href="about"> About </a> &bullet;

            <a href="contact"> Contact </a> &bullet;
        </hr>
        <p> ini halaman contact  <?php echo e($nama); ?> <?php echo e($gelar); ?></p>
    </body>
</html>